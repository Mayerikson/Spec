# Threat Modeling — roteiro STRIDE

1. Defina sistema, objetivo, ativos, atores, trust boundaries, fluxos e dependências.
2. Para cada fluxo/componente, considere: Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege.
3. Registre cenário, pré-condições, impacto, probabilidade, mitigação, teste e responsável.
4. Priorize riscos em função de exposição, privilégio, sensibilidade e impacto no negócio.
5. Atualize o modelo quando mudar arquitetura, autenticação, dados, integração ou superfície pública.

Não é necessário produzir um threat model extenso para script local de baixo risco; registre a avaliação proporcional.
