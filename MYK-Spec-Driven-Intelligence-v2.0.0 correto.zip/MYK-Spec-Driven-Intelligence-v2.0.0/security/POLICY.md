# Política de segurança e gates

## Severidade
- **Critical:** exploração provável com impacto grave (RCE, auth bypass amplo, segredo privilegiado exposto, exfiltração sensível). Bloqueia release.
- **High:** acesso indevido, exposição relevante de dados, vulnerabilidade explorável em componente exposto. Corrigir antes do release ou registrar exceção explícita com mitigação, responsável e prazo.
- **Medium:** impacto ou explorabilidade moderados; plano de correção e aceite de risco conforme contexto.
- **Low/Informational:** registrar quando útil, sem bloquear automaticamente.

CVSS pode apoiar priorização, mas não substitui contexto, exposição, criticidade do ativo e facilidade de exploração. Não inventar CVE ou severidade.

## Controles por contexto
- Todo projeto: segredos, dependências, validação de entradas, controle de acesso adequado e revisão de alterações sensíveis.
- API/autenticação: autorização por objeto/função, rate limiting, sessão/token, CORS, validação e abuso de fluxo.
- Dados pessoais: minimização, finalidade, retenção, controle de acesso, logs saneados e análise LGPD.
- Container/CI: imagem base, usuário não-root, permissões mínimas, secrets, actions pinadas quando viável, artefatos e permissões de workflow.
- ML/dados: proveniência, acesso, integridade, risco de exposição e governança dos dados.

## Exceções
Toda exceção exige finding, justificativa, impacto, mitigação, responsável, aprovador autorizado, data de expiração e plano de remediação. Não aceitar exceção para Critical sem processo formal de risco e autorização executiva especializada; por padrão, bloqueia.
