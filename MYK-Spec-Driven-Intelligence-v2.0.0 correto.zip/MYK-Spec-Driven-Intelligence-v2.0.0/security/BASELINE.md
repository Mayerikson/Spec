# Baseline de controles técnicos

| Área | Controle / ferramenta possível | Evidência esperada |
|---|---|---|
| Segredos | Gitleaks; secret manager; `.gitignore`; rotação | relatório saneado + política de acesso |
| SAST | Semgrep, CodeQL ou ferramenta compatível | versão, regras, resultado e triagem |
| SCA | Dependabot, osv-scanner, pip-audit, npm audit conforme stack | lockfile + relatório de vulnerabilidades |
| DAST | OWASP ZAP ou equivalente, apenas em alvo autorizado | escopo, configuração e relatório |
| API | testes de autenticação/autorização, IDOR/BOLA, rate limit | casos de teste e resultados |
| Container | Trivy/Grype, Dockerfile lint, usuário não-root | digest da imagem e relatório |
| CI/CD | permissões mínimas, proteção de branch, revisão, pinning de actions | configuração e histórico de PR/CI |
| Supply chain | SBOM (CycloneDX/SPDX), proveniência e assinatura quando aplicável | SBOM, digest, atestação |

Ferramentas são exemplos. Verifique disponibilidade, versão, licença e compatibilidade antes de instalar/adotar. Nenhuma ferramenta está instalada pelo pacote de skill.
