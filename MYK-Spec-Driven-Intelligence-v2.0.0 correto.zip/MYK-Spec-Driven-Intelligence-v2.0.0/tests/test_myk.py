import json, tempfile, subprocess, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; CLI=ROOT/'scripts/myk.py'
class TestCLI(unittest.TestCase):
 def runcli(self,*args): return subprocess.run([sys.executable,str(CLI),*args],capture_output=True,text=True)
 def test_init_creates_pending_draft(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.runcli('init','--workspace',d+'/p','--name','Teste'); self.assertEqual(r.returncode,0)
   x=json.loads((Path(d)/'p/.myk-state.json').read_text()); self.assertEqual(x['gates']['prd']['status'],'pending')
 def test_init_does_not_overwrite(self):
  with tempfile.TemporaryDirectory() as d:
   self.runcli('init','--workspace',d+'/p','--name','Teste'); r=self.runcli('init','--workspace',d+'/p','--name','Outro'); self.assertNotEqual(r.returncode,0)
 def test_missing_state_blocks(self):
  with tempfile.TemporaryDirectory() as d:
   r=self.runcli('check','--workspace',d,'--gate','release'); self.assertNotEqual(r.returncode,0)
 def test_route(self):
  r=self.runcli('route','--phase','qa','--domain','analytics'); self.assertEqual(r.returncode,0); self.assertIn('sdd-qa',r.stdout)
if __name__=='__main__': unittest.main()
