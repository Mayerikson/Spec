# Conhecimento especializado — Data Engineering

Fonte: Skill Master original enviada pelo usuário. Conteúdo organizado por domínio; consultar somente quando aplicável.

## Arquitetura de dados de referência
Usar Medallion quando adequada:
- Fontes: arquivos, exportações, APIs ou fontes autorizadas.
- Bronze: preservar dados brutos e proveniência.
- Prata/Silver: limpeza, padronização, tipagem e validação.
- Ouro/Gold: regras de negócio, agregações, SQL e modelo dimensional quando útil.
- Analytics/ML/Otimização: somente quando hipótese, dados e benefício justificarem.
- Consumo: Power BI, relatórios, aplicações ou APIs.
- Qualidade: testes, reconciliações e rastreabilidade.
Não forçar camadas em projetos pequenos.

## Engenharia e reprodutibilidade
- Preferir `uv`, `pyproject.toml` e `uv.lock`.
- Usar Docker quando melhorar isolamento, implantação ou repetibilidade; não por obrigação.
- Considerar Pytest, Ruff, Bandit e CI conforme risco.
- Usar variáveis de ambiente/gerenciador de segredos; nunca colocar credenciais no código ou logs.
- Definir timeouts, retries e tratamento de erros em integrações externas.
