# Conhecimento especializado — Architecture Tooling

Fonte: Skill Master original enviada pelo usuário. Conteúdo organizado por domínio; consultar somente quando aplicável.

## Engenharia e reprodutibilidade
- Preferir `uv`, `pyproject.toml` e `uv.lock`.
- Usar Docker quando melhorar isolamento, implantação ou repetibilidade; não por obrigação.
- Considerar Pytest, Ruff, Bandit e CI conforme risco.
- Usar variáveis de ambiente/gerenciador de segredos; nunca colocar credenciais no código ou logs.
- Definir timeouts, retries e tratamento de erros em integrações externas.

## Catálogo de tecnologias: critérios condicionais
- **Pydantic:** contratos, validação de objetos e entradas/saídas de APIs.
- **pydantic-settings:** configurações validadas por ambiente.
- **Logfire:** tracing, observabilidade e diagnóstico quando a complexidade justificar.
- **Pandera:** validação tabular e qualidade de DataFrames.
- **Pyomo:** modelagem matemática de otimização em Python (LP, MILP, NLP, MINLP, estocástica, GDP). Usar quando a decisão exigir escolher o melhor conjunto de ações sob restrições (alocação, mix de produção, planejamento, roteirização, escalonamento, rede logística). Ver seção "Otimização matemática com Pyomo". Não usar se uma regra simples, SQL, heurística ou `scipy.optimize` resolver.
- **PyMongo/MongoDB:** dados documentais/semiestruturados e workloads que se beneficiem de esquema flexível; evitar se DuckDB, Parquet, SQLite ou SQL resolverem melhor.
- **Calamine/python-calamine:** leitura de Excel e formatos suportados; não é ferramenta de edição.
- **Requests/httpx:** APIs e HTTP.
- **BeautifulSoup:** parsing de HTML estático.
- **Playwright/Selenium:** páginas dinâmicas ou interações de navegador necessárias.
- **Scrapy:** crawling/coleta maior e mais complexa.
- **pandas.read_html:** tabelas HTML.
- **DuckDB:** analytics local e SQL sobre arquivos.
- **SQLite:** banco relacional local simples.
- **PostgreSQL:** workloads relacionais compartilhados, concorrência e transações.
- **SQLAlchemy:** acesso relacional estruturado quando útil.
- **Airflow:** orquestração quando scripts/agendadores simples forem insuficientes.
- **logging/Loguru:** observabilidade proporcional; logging padrão pode bastar.
- **RapidAPI Hub:** avaliar custo, limites, autenticação, confiabilidade, direitos de uso e LGPD.
- **MCP e adaptadores cloud-agnostic:** somente com caso concreto.
Não adicionar ferramentas apenas para aumentar a stack.

## Ingestão web
Prioridade: API oficial/arquivo → HTTP (Requests/httpx) → parsing (BeautifulSoup/pandas.read_html) → navegador automatizado se necessário → Scrapy quando escala/complexidade justificarem. Registrar fonte e data da coleta; respeitar termos, limites, controles de acesso, licenças e LGPD.
