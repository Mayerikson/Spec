# Conhecimento especializado — Mathematical Optimization

Fonte: Skill Master original enviada pelo usuário. Conteúdo organizado por domínio; consultar somente quando aplicável.

## Otimização matemática com Pyomo
Pyomo é uma linguagem de modelagem algébrica em Python. Ela descreve o problema (variáveis, objetivo, restrições) separadamente do solver que o resolve.

### Quando usar
- A decisão é "o que fazer, quanto e quando" com recursos limitados e regras claras: mix de produção, alocação de pessoas/recursos, planejamento de estoque e compras, escalonamento de turnos, roteirização, localização de centros de distribuição, seleção de projetos/portfólio, blending.
- Existe um objetivo mensurável (minimizar custo/tempo, maximizar margem/receita/atendimento) e restrições explícitas (capacidade, demanda, orçamento, prazos, regras operacionais).
- A análise descritiva ou preditiva não basta: o negócio precisa de uma recomendação prescritiva.

### Quando evitar ou preferir alternativas
- Regra simples, SQL ou heurística resolve com qualidade suficiente.
- LP pequeno e simples: `scipy.optimize.linprog` ou PuLP.
- Problemas convexos: CVXPY.
- Escalonamento e restrições combinatórias complexas: OR-Tools (CP-SAT).
- Dados ou requisitos ainda incertos: validar o problema antes de modelar.

### Tipos de problema e solvers (verificar versão, licença e disponibilidade antes de adotar)
- LP/MILP: HiGHS (open source, `highspy`, boa primeira opção), CBC, GLPK, SCIP. Comerciais: Gurobi, CPLEX (verificar licença e custo).
- NLP: IPOPT.
- MINLP: SCIP, Bonmin, Couenne ou comerciais; avaliar se uma linearização resolve.
- Estocástica e GDP: extensões do ecossistema Pyomo, só com caso concreto.

### Estrutura recomendada do projeto
1. **Dados** (Gold/Silver): tabelas validadas com Pandera/Pydantic; unidades e granularidade explícitas.
2. **Modelo**: função que recebe dados validados e devolve o modelo Pyomo (`ConcreteModel` por padrão; `AbstractModel` só se a separação modelo/dados for necessária). Usar `Set`, `Param`, `Var`, `Constraint`, `Objective`.
3. **Solve**: `SolverFactory`, com `time limit`, `mip gap` e `seed` configuráveis por variáveis de ambiente/`pydantic-settings`.
4. **Pós-processamento**: ler variáveis, gerar tabelas de resultado e gravar de volta (Parquet/DuckDB/SQL) para consumo em Power BI ou API.
5. **Testes**: instâncias pequenas com solução conhecida, casos infactíveis/ilimitados e checagem das restrições na solução.

### Especificação de um projeto de otimização (registrar no SDD)
- Decisão apoiada e quem decide.
- Variáveis de decisão (tipo, domínio, unidade).
- Função objetivo e sentido (min/max).
- Restrições rígidas versus metas flexíveis (penalidades).
- Dados de entrada, fonte, granularidade e qualidade.
- Premissas e simplificações (lineariedade, determinismo, horizonte).
- Linha de base (solução atual/heurística) para comparar ganho.
- Critérios de aceite: viabilidade, tempo máximo de solução, gap aceitável, melhoria mínima sobre a linha de base.

### Boas práticas
- Começar com um modelo mínimo e adicionar restrições de forma incremental, validando a cada passo.
- Verificar `termination_condition` e `solver_status` antes de usar resultados; tratar infactibilidade e ilimitado de forma explícita.
- Evitar big-M mal calibrado e variáveis inteiras desnecessárias; avaliar relaxações.
- Explicabilidade: usar preços-sombra/duais (LP via `Suffix`), análise de sensibilidade e cenários ("e se") para justificar a recomendação.
- Registrar versão do Pyomo, do solver e parâmetros usados; fixar dependências com `uv.lock`.
- Separar fato (dados), premissa (modelo) e recomendação (resultado); o humano aprova a decisão final.
- Instalação típica: `uv add pyomo highspy` (confirmar pacote e solver conforme o caso).
- Considerar custo computacional: tamanho do modelo, tempo de solução e necessidade de solver comercial.
- Considerar LGPD e licenças de solver/dados.

### Integração com a arquitetura de dados
Gold alimenta o modelo → Pyomo resolve → resultados voltam como tabela Gold (cenário, versão, data, parâmetros) → consumo em Power BI/relatório/API, com rastreabilidade entre dados de entrada e recomendação.
