# Conhecimento especializado — Product Business

Fonte: Skill Master original enviada pelo usuário. Conteúdo organizado por domínio; consultar somente quando aplicável.

## Design Sprint e descoberta
Aplicar quando houver incerteza relevante sobre problema, usuário ou solução. Em projetos pequenos ou claros, simplificar ou dispensar.
- Dia 1: definir desafio, objetivo, perguntas críticas, entrevistas e jornada.
- Dia 2: explorar alternativas, Note and Vote, priorizar e criar storyboard.
- Dia 3: prototipar o suficiente para testar.
- Dia 4: testar com usuários representativos, sintetizar evidências e decidir próximos passos.
Práticas opcionais: Matriz CSD; entrevistas; How Might We/"Como podemos...?"; Note and Vote; mapa da jornada; hipóteses, riscos e critérios de sucesso; facilitador, decisor e participantes. Prototipar para aprender, não para polir. Exemplos específicos de workshops não são requisitos universais.

## Brand-Driven e Product-Driven
Quando pertinente, combinar:
- **Brand-Driven:** posicionamento, identidade, diferenciação, público, percepção, brand equity, reputação e contexto competitivo.
- **Product-Driven:** problemas do cliente, proposta de valor, descoberta, validação, adoção, engajamento, retenção, experimentação e monetização.
Conectar Marca → Produto → Experiência do cliente → Dados/Analytics → Resultado de negócio. Métricas possíveis: conversão, retenção, CAC, LTV, reconhecimento e rentabilidade; não presumir causalidade ou disponibilidade.

## Reuniões e comunicação executiva
Antes de reuniões importantes, verificar:
1. Objetivo da reunião.
2. Síntese do assunto em 30 segundos.
3. Participantes e interesses.
4. Dados/evidências para sustentar a posição.
5. Contexto atual da empresa/área.
6. Objeções e respostas.
7. Remoção de detalhes técnicos que não afetam a decisão.
8. Próximo passo proposto.
9. Responsável por cada ação.
10. Prazo concreto.
Sempre que possível, terminar com decisão, responsável, ação e prazo. Ajustar profundidade ao público.

## Portfólio e impacto
Estruturar cases por problema de negócio: contexto, oportunidade, hipóteses, dados e limitações, método, arquitetura, indicadores, resultados, interpretação, recomendações e próximos passos. Usar CRISP-DM, 5W2H, Scrum, SWOT, ROI, VPL, TIR, Payback, CBA, cenários e sensibilidade quando úteis. Algoritmos como K-means, PCA, LightGBM e SHAP não são obrigatórios. Em cases de otimização, mostrar a linha de base, o ganho obtido e as premissas do modelo.
