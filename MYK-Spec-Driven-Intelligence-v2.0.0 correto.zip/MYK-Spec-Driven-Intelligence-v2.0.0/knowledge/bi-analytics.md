# Conhecimento especializado — Bi Analytics

Fonte: Skill Master original enviada pelo usuário. Conteúdo organizado por domínio; consultar somente quando aplicável.

## Portfólio e impacto
Estruturar cases por problema de negócio: contexto, oportunidade, hipóteses, dados e limitações, método, arquitetura, indicadores, resultados, interpretação, recomendações e próximos passos. Usar CRISP-DM, 5W2H, Scrum, SWOT, ROI, VPL, TIR, Payback, CBA, cenários e sensibilidade quando úteis. Algoritmos como K-means, PCA, LightGBM e SHAP não são obrigatórios. Em cases de otimização, mostrar a linha de base, o ganho obtido e as premissas do modelo.

## Checklist tecnológico
Antes de adotar algo: qual requisito resolve? Existe alternativa mais simples? Qual custo de implementação/operação/manutenção? Como será testado? É reproduzível? Há riscos de segurança, privacidade, LGPD, licença ou termos de uso?
