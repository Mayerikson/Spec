# Conhecimento especializado — Data Science Ml

Fonte: Skill Master original enviada pelo usuário. Conteúdo organizado por domínio; consultar somente quando aplicável.

## Catálogo de tecnologias: critérios condicionais
- **Pydantic:** contratos, validação de objetos e entradas/saídas de APIs.
- **pydantic-settings:** configurações validadas por ambiente.
- **Logfire:** tracing, observabilidade e diagnóstico quando a complexidade justificar.
- **Pandera:** validação tabular e qualidade de DataFrames.
- **Pyomo:** modelagem matemática de otimização em Python (LP, MILP, NLP, MINLP, estocástica, GDP). Usar quando a decisão exigir escolher o melhor conjunto de ações sob restrições (alocação, mix de produção, planejamento, roteirização, escalonamento, rede logística). Ver seção "Otimização matemática com Pyomo". Não usar se uma regra simples, SQL, heurística ou `scipy.optimize` resolver.
- **PyMongo/MongoDB:** dados documentais/semiestruturados e workloads que se beneficiem de esquema flexível; evitar se DuckDB, Parquet, SQLite ou SQL resolverem melhor.
- **Calamine/python-calamine:** leitura de Excel e formatos suportados; não é ferramenta de edição.
- **Requests/httpx:** APIs e HTTP.
- **BeautifulSoup:** parsing de HTML estático.
- **Playwright/Selenium:** páginas dinâmicas ou interações de navegador necessárias.
- **Scrapy:** crawling/coleta maior e mais complexa.
- **pandas.read_html:** tabelas HTML.
- **DuckDB:** analytics local e SQL sobre arquivos.
- **SQLite:** banco relacional local simples.
- **PostgreSQL:** workloads relacionais compartilhados, concorrência e transações.
- **SQLAlchemy:** acesso relacional estruturado quando útil.
- **Airflow:** orquestração quando scripts/agendadores simples forem insuficientes.
- **logging/Loguru:** observabilidade proporcional; logging padrão pode bastar.
- **RapidAPI Hub:** avaliar custo, limites, autenticação, confiabilidade, direitos de uso e LGPD.
- **MCP e adaptadores cloud-agnostic:** somente com caso concreto.
Não adicionar ferramentas apenas para aumentar a stack.

## Portfólio e impacto
Estruturar cases por problema de negócio: contexto, oportunidade, hipóteses, dados e limitações, método, arquitetura, indicadores, resultados, interpretação, recomendações e próximos passos. Usar CRISP-DM, 5W2H, Scrum, SWOT, ROI, VPL, TIR, Payback, CBA, cenários e sensibilidade quando úteis. Algoritmos como K-means, PCA, LightGBM e SHAP não são obrigatórios. Em cases de otimização, mostrar a linha de base, o ganho obtido e as premissas do modelo.
