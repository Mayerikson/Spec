#!/usr/bin/env python3
import argparse, json, hashlib, re
from pathlib import Path

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def init(a):
 w=Path(a.workspace); w.mkdir(parents=True,exist_ok=True)
 p=w/'.myk-state.json'
 if p.exists(): raise SystemExit(f'ABORT: {p} já existe; não sobrescrito.')
 data={'project':{'name':a.name,'domain':a.domain,'risk':a.risk,'capabilities':{}},'gates':{k:{'status':'pending','approver':None,'approved_at':None,'sha256':None} for k in ['prd','techspec','planning']},'execution':{'remaining_blockers':[],'spec_drift':'pending'},'checks':{}}
 p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n'); print(f'RASCUNHO criado: {p}')
def route(a):
 routes={'discovery':'skills/sdd-discovery/MODULE.md','techspec':'skills/sdd-techspec/MODULE.md','planning':'skills/sdd-task-planning/MODULE.md','implementation':'skills/sdd-implementation/MODULE.md','qa':'skills/sdd-qa/MODULE.md','review':'skills/sdd-review/MODULE.md'}
 knowledge={'software':'knowledge/architecture-tooling.md','data-engineering':'knowledge/data-engineering.md','analytics':'knowledge/bi-analytics.md','data-science':'knowledge/data-science-ml.md','optimization':'knowledge/mathematical-optimization.md','product':'knowledge/product-business.md'}
 print('FASE:',routes[a.phase]); print('DOMÍNIO:',knowledge.get(a.domain,'sem módulo específico')); print('SEGURANÇA: skills/security-engine/MODULE.md (classificar risco)'); print('RISCO:',a.risk)
def check(a):
 w=Path(a.workspace); s=w/'.myk-state.json'
 if not s.exists(): raise SystemExit('BLOCKED: .myk-state.json ausente; inicialize ou faça baseline manual.')
 d=json.loads(s.read_text()); errors=[]
 gates={'implementation':['prd','techspec','planning'],'qa':['prd','techspec','planning'],'release':['prd','techspec','planning']}
 for g in gates[a.gate]:
  x=d.get('gates',{}).get(g,{})
  if x.get('status')!='approved' or not x.get('approver') or not x.get('approved_at') or not x.get('sha256'): errors.append(f'{g}: aprovação incompleta')
  filename={'prd':'prd.md','techspec':'techspec.md','planning':'tasks.md'}[g]; f=w/filename
  if not f.exists(): errors.append(f'{filename}: ausente')
  elif x.get('sha256') and sha(f)!=x['sha256']: errors.append(f'{filename}: hash divergente')
 if a.gate=='release':
  if d.get('execution',{}).get('remaining_blockers'): errors.append('há bloqueadores abertos')
  if d.get('execution',{}).get('spec_drift') not in ('none','approved'): errors.append('Spec Drift pendente')
  for key in ('qa','security','review'):
   x=d.get('checks',{}).get(key,{})
   if x.get('status') not in ('passed','not_applicable'): errors.append(f'{key}: não passou/não justificado')
 if errors:
  print('BLOCKED'); [print('- '+e) for e in errors]; raise SystemExit(2)
 print(f'CHECK estrutural {a.gate}: PASS. Isto valida registros e hashes locais; não autentica aprovador nem prova execução externa.')
def main():
 p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
 x=sub.add_parser('init'); x.add_argument('--workspace',required=True); x.add_argument('--name',required=True); x.add_argument('--domain',choices=['software','data-engineering','analytics','data-science','optimization','product'],default='software'); x.add_argument('--risk',choices=['low','medium','high','critical'],default='medium'); x.set_defaults(fn=init)
 x=sub.add_parser('route'); x.add_argument('--phase',choices=['discovery','techspec','planning','implementation','qa','review'],required=True); x.add_argument('--domain',choices=['software','data-engineering','analytics','data-science','optimization','product'],default='software'); x.add_argument('--risk',choices=['low','medium','high','critical'],default='medium'); x.set_defaults(fn=route)
 x=sub.add_parser('check'); x.add_argument('--workspace',required=True); x.add_argument('--gate',choices=['implementation','qa','release'],required=True); x.set_defaults(fn=check)
 x=sub.add_parser('hash'); x.add_argument('--file',required=True); x.set_defaults(fn=lambda a: print(sha(a.file)))
 a=p.parse_args(); a.fn(a)
if __name__=='__main__': main()
