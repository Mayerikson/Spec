# Roteamento

Classifique intenção, domínio (`software`, `data-engineering`, `analytics`, `data-science`, `optimization`, `product`), fase e risco. Sempre carregue Governance; fase ativa; no máximo dois módulos de conhecimento. Segurança desde Discovery e detalhada conforme risco.

| Fase | Skill |
|---|---|
| discovery | sdd-discovery |
| techspec | sdd-techspec |
| planning | sdd-task-planning |
| implementation | sdd-implementation |
| qa | sdd-qa |
| review | sdd-review |

Risco: Low (local, sem dados sensíveis); Medium (integração/dados internos); High (internet, auth, dados pessoais/financeiros, pagamentos); Critical (impacto grave, operação essencial, dados altamente sensíveis). Use classe mais conservadora quando incerto e peça validação para reduzir.
