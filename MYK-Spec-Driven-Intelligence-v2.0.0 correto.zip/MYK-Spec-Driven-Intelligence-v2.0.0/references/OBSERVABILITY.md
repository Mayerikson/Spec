# Explainability & Observability

ADR: contexto, opções, decisão, justificativa breve, evidências, trade-offs, risco e aprovador. Para ML/otimização: dados, premissas, limitações, incerteza e impacto.

Observabilidade aplicacional: logs estruturados, correlation ID, métricas de erro/latência/saturação, tracing, health checks, alertas, SLO e runbooks conforme necessidade. Redigir logs para não conter segredos/PII desnecessária. Diferenciar ambiente local, staging e produção.

Execução SDD: fase, task, run ID, timestamp, duração, comandos/versões, status, artefatos e bloqueios. Evidência scanner deve vir do scanner real.
