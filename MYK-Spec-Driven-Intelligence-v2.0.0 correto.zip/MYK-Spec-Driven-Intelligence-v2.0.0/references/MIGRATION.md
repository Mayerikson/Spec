# Migração v1 → v2

A v2 consolida cada fase SDD em `skills/`, modulariza o conhecimento da Skill Master em `knowledge/` e extrai a Security Pipeline em `security/`. Os três originais e todos os arquivos SDD de origem permanecem em `origins/` para auditoria. Conteúdo em `origins/` não é carregado automaticamente. Não herdar aprovações sem prova; revalidar artefatos e hashes.
