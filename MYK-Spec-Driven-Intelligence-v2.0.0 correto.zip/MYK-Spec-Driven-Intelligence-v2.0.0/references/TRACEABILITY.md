# IDs e rastreabilidade

Use `OBJ-*`, `RF-*`, `RNF-*`, `CA-*`, `ADR-*`, `TASK-*`, `TU-*`, `TI-*`, `E2E-*`, `SEC-*`, `EV-*`. Cada CA deve apontar para tarefa e teste/evidência ou justificativa de verificação manual.

Spec Drift: compare código, configuração e infraestrutura com TechSpec. `none` somente após comparação; `pending` bloqueia release; `approved` requer ADR, impacto, mitigação e aprovação. O script local valida estado declarado, não compara semântica do código.
