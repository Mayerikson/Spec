# Independência de QA e revisão

Implementador implementa. QA verifica comportamento/CA e registra defeitos. Remediação corrige e adiciona regressão. QA reexecuta. Revisor separado (pessoa, agente ou sessão isolada) examina diff, especificação, segurança e evidências, sem alterar código na sessão de revisão.

Se só houver um agente, declare `independent: false`; faça checklist separado, sem chamar a revisão de independente. Resultado: APPROVED, APPROVED_WITH_NOTES ou REJECTED. Bloqueadores impedem aprovação.
