# Portabilidade

Núcleo não presume APIs de agente, subagentes, hooks, slash commands, browser MCP ou terminal. Descubra capacidades reais. Sem filesystem, peça artefatos relevantes; sem terminal, forneça comandos como não executados; sem scanner, marque NOT_RUN; sem revisor independente, declare independência falsa. Adapte instruções para o ambiente sem alterar gates de segurança.
