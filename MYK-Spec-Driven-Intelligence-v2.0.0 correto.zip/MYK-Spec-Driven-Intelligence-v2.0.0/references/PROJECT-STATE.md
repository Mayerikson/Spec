# Estado do projeto

Estado opcional: `tasks/prd-[slug]/.myk-state.json`. `scripts/myk.py init` cria rascunho. Gates `prd`, `techspec`, `planning` têm status, aprovador, data e SHA-256 do artefato aprovado. Checks têm status, evidência e motivo. O CLI valida campos e hash, não identidade, execução de teste nem autenticidade.

Antes de implementar: PRD, TechSpec e planning aprovados; hash deve corresponder. Para QA/release: tasks concluídas, critérios e checks requeridos satisfeitos, drift resolvido. Consulte schema no `templates/project-state.example.json`.
