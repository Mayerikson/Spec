# Bounded Efficiency

Considere tokens/contexto, tempo, custo de cloud, latência, memória, manutenção e complexidade. Relate medido, estimado e não medido separadamente. Não adicione Kubernetes, Airflow, Kafka ou agentes sem justificativa. Limite tentativas; após repetição, diagnostique. Eficiência nunca remove controles críticos.
