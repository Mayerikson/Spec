---
name: quality-observability
description: Define estratégia de testes, qualidade, telemetria, SLOs e evidências verificáveis.
---
# Quality & Observability
- TechSpec define testes unitários, integração, contrato, E2E, segurança, performance e acessibilidade conforme risco.
- QA liga cada `CA-*` a teste e evidência.
- Logs estruturados, métricas, tracing e alertas só quando justificáveis pela arquitetura; não registrar PII/segredos desnecessários.
- Diferencie telemetria projetada, implementada, testada localmente e observada em produção.
- Use `references/OBSERVABILITY.md` e `templates/EVIDENCE.md`.
