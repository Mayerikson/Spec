---
name: efficiency-engine
description: Controla custo, contexto, latência e complexidade sem comprometer segurança ou critérios de aceite.
---
# Bounded Efficiency
- Carregue somente os módulos pertinentes; prefira inspeção direcionada e diff.
- Estime custo e esforço antes de infraestrutura adicional; distinga medido de estimado.
- Defina limite de tentativas; após falhas repetidas, pare e investigue causa raiz.
- Use subagentes quando isolamento ou especialização melhorar a verificação.
- Não reduzir controles de segurança, privacidade ou QA para economizar tokens/tempo.
- Consulte `references/EFFICIENCY.md`.
