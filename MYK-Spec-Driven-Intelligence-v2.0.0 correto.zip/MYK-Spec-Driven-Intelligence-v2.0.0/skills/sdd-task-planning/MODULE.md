---
name: sdd-task-planning
description: Módulo MYK para planejamento de tarefas dentro do ciclo Spec-Driven Development. Ative quando essa fase for solicitada ou for a próxima etapa autorizada.
---

O argumento `--prd` identifica o slug da funcionalidade. Sem argumento, localize a pasta em `./tasks/prd-*/`. Os arquivos obrigatórios são `tasks/prd-[slug]/prd.md` e `tasks/prd-[slug]/techspec.md`; se algum estiver ausente, pare e indique a skill correspondente (`sdd-discovery` ou `sdd-techspec`).

Cada tarefa é uma **entrega incremental**, com escopo claro, dependências explícitas e testes próprios. Referencie os critérios de aceitação do PRD e use os casos de teste definidos na TechSpec como fonte de verdade para os testes das tarefas. Referencie o `techspec.md` em vez de repetir detalhes de implementação.

## Fluxo

1. **Analisar** — leia o `AGENTS.md`, todas as rules em `.agents/rules/`, o PRD e a TechSpec; inventarie os requisitos, os critérios de aceitação (`CA-*`), as decisões técnicas, os componentes e todos os casos de teste definidos na TechSpec. Identifique as skills nas skills disponíveis no ambiente aplicáveis a cada tarefa.
   **Conclua quando:** o inventário de critérios e casos de teste estiver completo e as skills aplicáveis a cada tarefa estiverem identificadas.

2. **Propor a estrutura** — monte uma lista de tarefas de alto nível, preferencialmente com no máximo 10 itens. Liste as dependências antes das tarefas que dependem delas, como backend antes de frontend quando o frontend depender dele, e ambos antes dos testes E2E. Mostre a lista ao usuário para aprovação antes de gerar qualquer arquivo.
   **Conclua quando:** o usuário aprovar a lista.

3. **Gerar os arquivos** — em `./tasks/prd-[slug]/`:
   - `tasks.md` seguindo `./references/TEMPLATE_TASKS.md` desta skill
   - um arquivo `task_[num].md` para cada tarefa, seguindo `./references/TEMPLATE_TASK.md` desta skill. Use números sequenciais a partir de 1 (`task_1.md`, `task_2.md`, …) e inclua subtarefas (`[num].1`, `[num].2`, …), referências aos critérios de aceitação (`CA-*`) e os testes correspondentes aos casos mapeados da TechSpec
     **Conclua quando:** cada critério de aceitação e caso de teste do inventário estiver mapeado em uma ou mais tarefas, e os testes de cada tarefa corresponderem aos casos definidos na TechSpec.

4. **Reportar** — apresente os arquivos gerados e aguarde a confirmação do usuário antes de iniciar qualquer implementação.

## Regras MYK de controle
- Confirme os pré-requisitos da fase e o status dos gates em `.myk-state.json`, quando existir; ausência de estado não significa aprovação.
- Não afirme que uma ferramenta, teste, scanner, navegador ou agente foi usado sem execução observável. Se indisponível, registre `BLOCKED` ou `NOT_RUN`.
- Preserve arquivos existentes; antes de sobrescrever, examine diff e mantenha possibilidade de reversão.
- Vincule decisões e entregas a IDs de rastreabilidade e registre evidências.
- Consulte `references/INDEPENDENT-REVIEW.md` nas fases QA e Review.
