---
name: domain-knowledge
description: Seleciona módulos de conhecimento técnico MYK por domínio do projeto, sem carregar a biblioteca inteira.
---
# Domain Knowledge Router
1. Identifique domínio e necessidade técnica real.
2. Carregue no máximo dois arquivos `knowledge/*.md` diretamente relevantes; exceções justificadas em projetos multidisciplinares.
3. Preserve recomendações condicionais: tecnologia é opção, não obrigação.
4. Não invente que a Skill Master contém conteúdo que não esteja nos módulos. Consulte `origins/skill-master/MODULE.md` apenas para aprofundamento específico.
5. Mapeamento: software → architecture-tooling; data-engineering → data-engineering; analytics/BI → bi-analytics; data-science/ML → data-science-ml; optimization → mathematical-optimization; product → product-business; privacidade/governança → governance.
