---
name: sdd-discovery
description: Módulo MYK para discovery e prd dentro do ciclo Spec-Driven Development. Ative quando essa fase for solicitada ou for a próxima etapa autorizada.
---

O PRD define o problema, os objetivos, os resultados esperados, as restrições e o escopo. Objetivos e resultados devem ter critérios mensuráveis. Os detalhes de implementação — como arquitetura e código — pertencem à TechSpec e ficam fora do PRD.

## Fluxo de trabalho

1. **Esclarecer** — faça perguntas ao usuário usando `perguntas diretas ao usuário` antes de redigir:
   - Problema a ser resolvido e metas mensuráveis
   - Usuários principais, histórias de usuário e fluxos principais
   - Funcionalidades centrais: entradas, saídas e ações
   - Itens fora do escopo e dependências
   - Diretrizes de UI/UX e acessibilidade

   Para regras de negócio específicas do domínio, pesquise na web em vez de perguntar ao usuário.
   **Conclua quando:** cada seção do template tiver uma resposta ou premissa registrada.

2. **Redigir** — leia `./references/TEMPLATE.md` desta skill na íntegra e siga sua estrutura exatamente.
   **Conclua quando:** toda seção do template estiver preenchida com informações específicas da funcionalidade ou do produto.

3. **Salvar e reportar** — grave o documento em `./tasks/prd-[slug]/prd.md`, usando um slug da funcionalidade em kebab-case. Informe o caminho com um resumo de uma linha.

## Regras MYK de controle
- Confirme os pré-requisitos da fase e o status dos gates em `.myk-state.json`, quando existir; ausência de estado não significa aprovação.
- Não afirme que uma ferramenta, teste, scanner, navegador ou agente foi usado sem execução observável. Se indisponível, registre `BLOCKED` ou `NOT_RUN`.
- Preserve arquivos existentes; antes de sobrescrever, examine diff e mantenha possibilidade de reversão.
- Vincule decisões e entregas a IDs de rastreabilidade e registre evidências.
- Consulte `references/INDEPENDENT-REVIEW.md` nas fases QA e Review.
