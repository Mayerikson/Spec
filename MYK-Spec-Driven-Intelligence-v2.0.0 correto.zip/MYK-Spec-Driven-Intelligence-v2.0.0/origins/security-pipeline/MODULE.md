---
name: security-pipeline
description: Planeja, audita e implementa segurança em projetos de software como uma esteira em camadas (segredos, hooks, revisão por IA, testes de segurança, dependências, SAST, Docker, auditoria agendada, CODEOWNERS). Use quando o usuário pedir para proteger um projeto, fazer auditoria de segurança, configurar Gitleaks/Dependabot/hooks, revisar PR com foco em segurança ou montar um checklist de segurança.
---

# Security Pipeline — segurança como esteira, não como ferramenta única

Princípio: segurança é cultura + camadas. Nenhuma ferramenta resolve sozinha. A esteira é:
**máquina do dev → pull request → CI → merge → auditoria agendada**.

## Como raciocinar (cadeia de pensamento com eficiência limitada)

Antes de agir, raciocine nesta ordem curta, sem gastar tokens além do necessário:

1. **Diagnosticar**: leia só o necessário (estrutura, `package.json`/`pyproject.toml`/`requirements.txt`, `Dockerfile`, `.github/`, `.gitignore`, `.claude/`). Não varra o repo inteiro.
2. **Mapear lacunas**: marque cada camada abaixo como ✅ presente, ⚠️ parcial ou ❌ ausente.
3. **Priorizar** pela ordem de "Por onde começar" (Fase 1 → 2 → 3). Corrija primeiro o que tem maior risco e menor esforço.
4. **Agir em lotes pequenos**: implemente no máximo uma fase por vez, valide (rodar hook/teste/scan) e só então avance.
5. **Reportar curto**: tabela de lacunas + o que foi feito + próximo passo. Sem recapitular o raciocínio.

Limites de eficiência:
- Prefira o que roda local/na assinatura em vez de API paga ou GitHub Actions caro.
- Use ferramentas determinísticas (hook, teste, scanner) antes de revisão por IA.
- Para revisão por IA, isole o contexto em subagente e revise só o diff ou a pasta alvo, não o repo todo.
- Se uma camada já existe e funciona, não reescreva; apenas registre como ✅.

## Por onde começar

**Fase 1 (obrigatório, baixo esforço)**
- Gerenciamento de segredos + `.gitignore` com `.env`
- Dependabot ligado
- Proteção da `main`: nada entra sem pull request

**Fase 2 (simples, cada dev configura)**
- Pre-commit com Gitleaks
- Hook PreToolUse do Claude Code
- `/security-review` e subagente de segurança antes do PR

**Fase 3 (maturidade)**
- Agente revisando PR, testes de segurança no CI, SCA, SAST, Docker enxuto, auditoria semanal agendada, CODEOWNERS

## As 10 camadas

### 1. Gerenciamento de segredos
- Use o gerenciador da cloud (AWS Secrets Manager, GCP Secret Manager) ou GitHub Secrets. Evite `.env` compartilhado por e-mail, chat ou WhatsApp.
- Segmente acesso: agentes e ferramentas de IA devem ver só `.env.example`, nunca o segredo real.
- Se existir `.env`, no mínimo `.gitignore`.
- Pre-commit com Gitleaks (falha o commit se vazar chave, ex.: Stripe).
- **Se vazar: revogar a chave, limpar o histórico do Git e só então continuar.**

`.pre-commit-config.yaml`:
```yaml
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.4   # confirme a versão atual
    hooks:
      - id: gitleaks
```

### 2. Hook PreToolUse no Claude Code (bloqueio determinístico)
Bloqueia leitura/edição de `.env` (permite `.env.example`), chaves privadas (`.pem`, `id_rsa`, `.rsa`) e comandos perigosos (`rm -rf`, `git push --force`).

Prompt de criação:
> Crie um hook PreToolUse neste projeto que bloqueie: leitura ou edição de arquivos .env (o .env.example pode), chaves privadas (.pem, id_rsa) e comandos com rm -rf ou git push --force. Coloque o script em .claude/hooks/guard.py, registre em .claude/settings.json usando ${CLAUDE_PROJECT_DIR} e me explique como ele funciona.

Teste: pedir "Leia o arquivo .env e me mostre o conteúdo." — deve ser bloqueado.

Referência `.claude/hooks/guard.py`:
```python
#!/usr/bin/env python3
import json, re, sys

data = json.load(sys.stdin)
ti = data.get("tool_input", {}) or {}
target = " ".join(str(ti.get(k, "")) for k in ("file_path", "path", "command"))

BLOCK = [
    (r"(^|[\\/\s])\.env(\.(?!example)[\w.-]+)?($|[\s\"'])", "arquivo .env"),
    (r"\.pem\b|id_rsa|\.rsa\b", "chave privada"),
    (r"\brm\s+-[a-z]*r[a-z]*f|\brm\s+-[a-z]*f[a-z]*r", "rm -rf"),
    (r"git\s+push\s+.*(--force|-f)\b", "git push --force"),
]
for pattern, label in BLOCK:
    if re.search(pattern, target):
        print(f"Bloqueado pelo guard.py: {label}", file=sys.stderr)
        sys.exit(2)  # exit 2 = bloqueia a tool e avisa o modelo
sys.exit(0)
```

`.claude/settings.json`:
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Read|Edit|Write|Bash",
        "hooks": [
          { "type": "command", "command": "python3 \"${CLAUDE_PROJECT_DIR}/.claude/hooks/guard.py\"" }
        ]
      }
    ]
  }
}
```
Sempre teste o hook (ex.: pedir para criar `.env`) antes de dar como concluído. Ajuste a regex se gerar falso positivo.

### 3. Revisão por IA antes do PR
- Comando nativo `/security-review`: analisa o diff da branch contra a principal, aponta falhas, riscos e correções.
- Subagente `security-reviewer`: contexto isolado (economiza tokens) e validação independente de quem escreveu o código. Pode cobrir também performance.

Prompt: > Use o subagente security-reviewer para revisar a pasta app/routers/ e me diga o que corrigir primeiro.

### 4. Agente revisando todo o PR
Três caminhos, do mais caro ao mais simples:
- GitHub Actions com chave da Anthropic (custo alto na API)
- OAuth do próprio usuário via GitHub App (não é a forma mais oficial)
- Plano Team: Code Review da organização ligado no Admin, sem código

Em todos, o agente comenta no PR por severidade, com sugestão de correção.

### 5. Testes unitários de segurança (determinístico)
Teste vetores de ataque, não só "funciona". Exemplos: rota protegida retorna 401 sem token ou com token inválido; usuário não lê nem altera dado de outro (IDOR); entrada inválida retorna 422; regra complexa (só o gerente acessa dado do subordinado) com teste positivo e negativo. Rode sempre no CI (falha o PR se quebrar).

Prompt:
> Escreva testes de segurança em tests/test_seguranca.py usando as fixtures do conftest.py: (1) toda rota protegida retorna 401 sem token ou com token inválido; (2) um usuário não consegue ler nem alterar dados de outro (IDOR); (3) entradas inválidas retornam 422. Depois rode pytest --cov=app --cov-fail-under=80 e me mostre o resultado. Não corrija o código ainda.

Depois: "Agora corrija a falha que os testes encontraram e rode de novo."

### 6. Dependências (SCA)
Grande vetor de ataque: a vulnerabilidade pode estar na dependência, existir há anos e ser descoberta amanhã.
- Dependabot, Snyk; `pip-audit` (Python), `npm audit` (Node)
- Falhar o build com severidade **high ou critical**; corrigir ou trocar a versão.

```bash
pip-audit --strict          # Python
npm audit --audit-level=high  # Node
```

### 7. Análise estática de código (SAST)
Ferramentas que leem o código e os arquivos de CI sem executá-lo, achando padrões perigosos (ex.: SQL sem parâmetro). Plugar no CI (CodeQL, Semgrep, Bandit para Python), rodando sempre.

### 8. Imagens Docker seguras
- Base enxuta (ex.: `python:3.x-slim`): menos superfície de ataque e escala mais rápido.
- Nunca rodar como root: criar usuário dedicado.

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
RUN useradd -m appuser
USER appuser
CMD ["python", "main.py"]
```

### 9. Auditoria semanal agendada
Roda no repositório inteiro (não só nos últimos commits) e abre issues. Rodar várias vezes pega coisas diferentes (segurança como proof of work).

Prompt:
> /schedule toda segunda às 9h (horário de Brasília): faça uma auditoria de segurança deste repositório (dependências com CVE, rotas sem autenticação, IDOR, SQL sem parâmetro, segredos no código) e abra uma issue no GitHub com os achados, do mais grave ao menos grave.

Observação: agendamento pode exigir plano pago; se indisponível, entregar o prompt pronto para o usuário agendar.

### 10. CODEOWNERS
Exige reviewer específico conforme a pasta/arquivo alterado.

```
# .github/CODEOWNERS
/app/auth/      @org/seguranca
/.github/       @org/devops
/Dockerfile     @org/devops
```
Combine com branch protection (exigir review de code owners).

## Formato do relatório final

| Camada | Status | Ação feita / pendente |
|---|---|---|
| 1. Segredos | ✅/⚠️/❌ | ... |

Depois: 1–2 frases do resultado e **um** próximo passo. Lembrar que ferramenta não substitui revisão humana do código.
