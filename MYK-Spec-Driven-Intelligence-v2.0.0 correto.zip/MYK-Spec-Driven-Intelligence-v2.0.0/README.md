# MYK Spec-Driven Intelligence 2.0.0

Skill modular para conduzir projetos por especificações, com seis fases SDD, conhecimento técnico sob demanda, segurança por risco, QA/revisão, rastreabilidade e controles locais.

## Instalação
1. Extraia o ZIP preservando a pasta `MYK-Spec-Driven-Intelligence-v2.0.0/` e toda a hierarquia interna.
2. Instale a pasta completa como skill principal no diretório de skills reconhecido pelo agente.
3. Confirme que o agente consegue ler `SKILL.md` e arquivos internos em `skills/`, `knowledge/`, `security/` e `references/`.
4. Faça um teste em projeto de demonstração: peça Discovery e confirme que a skill não inicia implementação antes dos gates.
5. Execute a auditoria local: `python scripts/audit_package.py .` e `python -m unittest discover -s tests -v`.

## Estrutura
- `SKILL.md`: orquestrador central.
- `skills/`: seis etapas SDD e especialistas transversais.
- `knowledge/`: conhecimento Skill Master dividido por domínio.
- `security/`: política, baseline e threat modeling.
- `references/`: roteamento, governança, estado, rastreabilidade, eficiência, observabilidade e portabilidade.
- `templates/`: ADR, evidências, findings e estado de exemplo.
- `scripts/`: CLI local de inicialização, roteamento, hash e validação de gates.
- `tests/`: testes unitários do CLI.
- `evals/`: protocolo de avaliação comportamental em agentes reais.
- `origins/`: cópias integrais dos três materiais-fonte. São arquivo de proveniência, não módulos carregados automaticamente.

## Limitações importantes
O pacote não instala Gitleaks, Semgrep, CodeQL, ZAP, Trivy, Dependabot, hooks, CI/CD ou subagentes. Ele descreve como selecionar e validar essas capacidades quando disponíveis. O CLI não autentica aprovadores, não prova execução de scanners/testes e não faz análise semântica do código. Testes comportamentais em agentes reais ainda precisam ser executados.

## Migração
Consulte `references/MIGRATION.md`. Não considere aprovações antigas automaticamente válidas; faça baseline e revalidação dos artefatos.
