---
name: security-engine
description: Planeja e verifica controles de segurança proporcionais ao risco em código, APIs, dependências, containers, CI/CD e dados.
---
# Security Engineering Engine

## Operação
1. Defina escopo autorizado, ativos, dados, fronteiras de confiança, exposição e impacto.
2. Modele ameaças com STRIDE quando adequado; priorize abuso de autenticação/autorização, injeção, exposição de dados, SSRF, supply chain e segredos.
3. Selecione controles em `security/BASELINE.md` por risco e stack.
4. Inspecione apenas arquivos e artefatos necessários; nunca leia nem revele segredos.
5. Execute scanners apenas se instalados, autorizados e no escopo. Registre versão, comando, data, alvo e relatório saneado.
6. Corrija por lotes pequenos, rode testes de regressão e revalide.
7. Bloqueie release em finding Critical; High exige correção ou exceção formal aprovada.

## Regras inegociáveis
- Não executar pentest, fuzzing agressivo, exploração, brute force ou scans externos sem autorização explícita e limites definidos.
- Não instalar dependências nem alterar CI, permissões, firewall, secrets store ou branches protegidas sem consentimento.
- Se ferramenta ausente: `NOT_RUN`/`BLOCKED`, nunca PASS.
- Um review de IA não substitui scanner determinístico nem revisão humana exigida pelo risco.
- Vazamento confirmado: interromper uso, orientar revogação/rotação e investigação do histórico; não reproduzir o valor secreto.

Consulte `security/POLICY.md`, `security/BASELINE.md`, `security/THREAT-MODELING.md` e `origins/security-pipeline/SKILL.md` para detalhes históricos.
