#!/usr/bin/env python3
from pathlib import Path
import sys, re, json
root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
errors=[]; skills=list(root.rglob('SKILL.md'))
for p in skills:
 t=p.read_text(encoding='utf-8')
 if not t.startswith('---\n') or t.count('---')<2: errors.append(f'{p}: frontmatter ausente')
 if not re.search(r'^name:\s*[^\s]+',t,re.M): errors.append(f'{p}: name ausente')
 if not re.search(r'^description:\s*.+',t,re.M): errors.append(f'{p}: description ausente')
for p in root.rglob('*.md'):
 for rel in re.findall(r'\[[^]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if rel.startswith(('http://','https://','#','mailto:')): continue
  target=(p.parent/rel.split('#')[0]).resolve()
  if rel.split('#')[0] and not target.exists(): errors.append(f'{p}: link local quebrado {rel}')
if not (root/'SKILL.md').exists(): errors.append('SKILL.md raiz ausente')
if errors:
 print('FAIL'); print('\n'.join(errors)); sys.exit(1)
print(f'PASS: {len(skills)} SKILL.md; links locais resolvidos; estrutura raiz presente.')
