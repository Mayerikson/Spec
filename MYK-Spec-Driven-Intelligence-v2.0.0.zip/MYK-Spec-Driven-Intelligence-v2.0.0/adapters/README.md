# Adaptadores de plataforma

O pacote é uma skill principal com módulos internos. Instale a pasta inteira preservando paths. `skills/*/SKILL.md` são módulos invocados pelo orquestrador, não necessariamente descobertos como skills autônomas. Para agentes que só aceitam um único arquivo, use `SKILL.md` e disponibilize a pasta inteira como referências acessíveis. Não presuma que o agente lê subpastas automaticamente: teste o acesso.

Adapte comandos e integrações conforme capacidades reais do host. Hooks da Security Pipeline original são específicos do Claude Code e não são universais. Consulte `references/PORTABILITY.md`.
